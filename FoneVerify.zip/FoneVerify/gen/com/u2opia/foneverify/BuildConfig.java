/** Automatically generated file. DO NOT MODIFY */
package com.u2opia.foneverify;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}