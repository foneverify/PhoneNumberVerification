package com.u2opia.foneverify.utility;

public class OTPSMS {
	public static String mStrOtp = "";

	public static void setOtp(String mStrOtp) {
		OTPSMS.mStrOtp = mStrOtp;
	}

	public static String getOtp() {
		return mStrOtp;
	}

}
